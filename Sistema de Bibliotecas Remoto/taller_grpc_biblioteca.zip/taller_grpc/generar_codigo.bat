@echo off
REM generar_codigo.bat — Genera los archivos Python a partir del .proto
REM Ejecutar UNA SOLA VEZ antes de correr el servidor o el cliente.

echo =^> Instalando dependencias...
pip install grpcio grpcio-tools

echo =^> Generando codigo Python desde biblioteca.proto...
python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. biblioteca.proto

echo.
echo OK Archivos generados:
echo    - biblioteca_pb2.py
echo    - biblioteca_pb2_grpc.py
echo.
echo Ya puedes ejecutar el servidor y el cliente.
pause
