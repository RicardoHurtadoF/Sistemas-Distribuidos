"""
servidor.py — Servidor gRPC de la Biblioteca
============================================
Ejecutar:
    python servidor.py [puerto]
    python servidor.py 50051          (por defecto)
"""

import grpc
import json
import os
import threading
from concurrent import futures
from datetime import date, timedelta

import biblioteca_pb2
import biblioteca_pb2_grpc

# ─── Ruta al archivo de datos ───────────────────────────────────────────────
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
DB_PATH    = os.path.join(BASE_DIR, "libros.json")
LOCK       = threading.Lock()  # protege lecturas/escrituras concurrentes


# ─── Helpers de base de datos ───────────────────────────────────────────────

def cargar_libros():
    """Lee el archivo JSON y retorna la lista de libros."""
    with open(DB_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def guardar_libros(libros):
    """Persiste la lista de libros en el archivo JSON."""
    with open(DB_PATH, "w", encoding="utf-8") as f:
        json.dump(libros, f, ensure_ascii=False, indent=2)


def fecha_devolucion():
    """Retorna la fecha de devolución (hoy + 7 días) como string."""
    return (date.today() + timedelta(days=7)).strftime("%Y-%m-%d")


def buscar_por_isbn(libros, isbn):
    """Retorna el índice y el libro que coincida con el ISBN, o (None, None)."""
    for i, libro in enumerate(libros):
        if libro["isbn"] == isbn:
            return i, libro
    return None, None


def buscar_por_titulo(libros, titulo):
    """Búsqueda case-insensitive por título (coincidencia parcial)."""
    titulo_lower = titulo.strip().lower()
    for i, libro in enumerate(libros):
        if titulo_lower in libro["titulo"].lower():
            return i, libro
    return None, None


# ─── Implementación del servicio ────────────────────────────────────────────

class BibliotecaServicer(biblioteca_pb2_grpc.BibliotecaServicer):
    """Implementa los cuatro métodos remotos definidos en biblioteca.proto."""

    # ── 1. Préstamo por ISBN ─────────────────────────────────────────────────
    def PrestamoPorISBN(self, request, context):
        print(f"[PRÉSTAMO ISBN] isbn='{request.isbn}'")
        with LOCK:
            libros = cargar_libros()
            idx, libro = buscar_por_isbn(libros, request.isbn)

            if libro is None:
                return biblioteca_pb2.RespuestaPrestamo(
                    aprobado=False,
                    mensaje=f"Libro con ISBN '{request.isbn}' no encontrado."
                )

            disponibles = libro["ejemplares_total"] - libro["prestados"]
            if disponibles <= 0:
                return biblioteca_pb2.RespuestaPrestamo(
                    aprobado=False,
                    mensaje=f"No hay ejemplares disponibles de '{libro['titulo']}'."
                )

            # Registrar el préstamo
            libros[idx]["prestados"] += 1
            guardar_libros(libros)

            fecha = fecha_devolucion()
            print(f"  → Préstamo aprobado. Devolución: {fecha}")
            return biblioteca_pb2.RespuestaPrestamo(
                aprobado=True,
                mensaje=f"Préstamo de '{libro['titulo']}' aprobado.",
                fecha_devolucion=fecha
            )

    # ── 2. Préstamo por título ───────────────────────────────────────────────
    def PrestamoPorTitulo(self, request, context):
        print(f"[PRÉSTAMO TÍTULO] titulo='{request.titulo}'")
        with LOCK:
            libros = cargar_libros()
            idx, libro = buscar_por_titulo(libros, request.titulo)

            if libro is None:
                return biblioteca_pb2.RespuestaPrestamo(
                    aprobado=False,
                    mensaje=f"No se encontró ningún libro con título '{request.titulo}'."
                )

            disponibles = libro["ejemplares_total"] - libro["prestados"]
            if disponibles <= 0:
                return biblioteca_pb2.RespuestaPrestamo(
                    aprobado=False,
                    mensaje=f"No hay ejemplares disponibles de '{libro['titulo']}'."
                )

            libros[idx]["prestados"] += 1
            guardar_libros(libros)

            fecha = fecha_devolucion()
            print(f"  → Préstamo aprobado. Devolución: {fecha}")
            return biblioteca_pb2.RespuestaPrestamo(
                aprobado=True,
                mensaje=f"Préstamo de '{libro['titulo']}' aprobado.",
                fecha_devolucion=fecha
            )

    # ── 3. Consulta de disponibilidad ────────────────────────────────────────
    def Consulta(self, request, context):
        print(f"[CONSULTA] isbn='{request.isbn}'")
        with LOCK:
            libros = cargar_libros()
            _, libro = buscar_por_isbn(libros, request.isbn)

        if libro is None:
            return biblioteca_pb2.RespuestaConsulta(encontrado=False)

        disponibles = libro["ejemplares_total"] - libro["prestados"]
        print(f"  → '{libro['titulo']}': {disponibles}/{libro['ejemplares_total']} disponibles")
        return biblioteca_pb2.RespuestaConsulta(
            encontrado=True,
            titulo=libro["titulo"],
            autor=libro["autor"],
            ejemplares_total=libro["ejemplares_total"],
            ejemplares_disp=disponibles
        )

    # ── 4. Devolución ────────────────────────────────────────────────────────
    def Devolucion(self, request, context):
        print(f"[DEVOLUCIÓN] isbn='{request.isbn}'")
        with LOCK:
            libros = cargar_libros()
            idx, libro = buscar_por_isbn(libros, request.isbn)

            if libro is None:
                return biblioteca_pb2.RespuestaDevolucion(
                    exitoso=False,
                    mensaje=f"Libro con ISBN '{request.isbn}' no encontrado."
                )

            if libro["prestados"] == 0:
                return biblioteca_pb2.RespuestaDevolucion(
                    exitoso=False,
                    mensaje=f"'{libro['titulo']}' no tiene préstamos activos."
                )

            libros[idx]["prestados"] -= 1
            guardar_libros(libros)

            print(f"  → Devolución registrada.")
            return biblioteca_pb2.RespuestaDevolucion(
                exitoso=True,
                mensaje=f"Devolución de '{libro['titulo']}' registrada exitosamente."
            )


# ─── Arranque del servidor ───────────────────────────────────────────────────

def serve(puerto=50051):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    biblioteca_pb2_grpc.add_BibliotecaServicer_to_server(BibliotecaServicer(), server)
    server.add_insecure_port(f"[::]:{puerto}")
    server.start()
    print(f"╔══════════════════════════════════════╗")
    print(f"║  Servidor Biblioteca gRPC corriendo  ║")
    print(f"║  Puerto: {puerto:<27} ║")
    print(f"╚══════════════════════════════════════╝")
    print("Esperando conexiones... (Ctrl+C para detener)\n")
    try:
        server.wait_for_termination()
    except KeyboardInterrupt:
        print("\nServidor detenido.")
        server.stop(0)


if __name__ == "__main__":
    import sys
    puerto = int(sys.argv[1]) if len(sys.argv) > 1 else 50051
    serve(puerto)
