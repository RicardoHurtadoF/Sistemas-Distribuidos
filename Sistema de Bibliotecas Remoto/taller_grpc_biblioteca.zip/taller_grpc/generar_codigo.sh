#!/usr/bin/env bash
# generar_codigo.sh — Genera los archivos Python a partir del .proto
# Ejecutar UNA SOLA VEZ antes de correr el servidor o el cliente.
# Compatible con Linux/macOS. En Windows usar Git Bash o WSL.

set -e

echo "==> Instalando dependencias..."
pip install grpcio grpcio-tools --quiet

echo "==> Generando código Python desde biblioteca.proto..."
python -m grpc_tools.protoc \
    -I. \
    --python_out=. \
    --grpc_python_out=. \
    biblioteca.proto

echo ""
echo "✔ Archivos generados:"
echo "   - biblioteca_pb2.py"
echo "   - biblioteca_pb2_grpc.py"
echo ""
echo "Ya puedes ejecutar el servidor y el cliente."
