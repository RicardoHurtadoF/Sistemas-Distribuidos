"""
cliente.py — Cliente interactivo de la Biblioteca gRPC
=======================================================
Ejecutar:
    python cliente.py [host] [puerto]
    python cliente.py 192.168.1.10 50051
    python cliente.py localhost 50051    (por defecto)
"""

import grpc
import sys

import biblioteca_pb2
import biblioteca_pb2_grpc


# ─── Conexión ────────────────────────────────────────────────────────────────

def conectar(host="localhost", puerto=50051):
    canal = grpc.insecure_channel(f"{host}:{puerto}")
    stub  = biblioteca_pb2_grpc.BibliotecaStub(canal)
    return stub


# ─── Funciones de cada operación ─────────────────────────────────────────────

def prestamo_isbn(stub):
    isbn = input("  Ingresa el ISBN del libro: ").strip()
    resp = stub.PrestamoPorISBN(biblioteca_pb2.SolicitudISBN(isbn=isbn))
    if resp.aprobado:
        print(f"  ✔ {resp.mensaje}")
        print(f"  ✔ Fecha de devolución: {resp.fecha_devolucion}")
    else:
        print(f"  ✘ {resp.mensaje}")


def prestamo_titulo(stub):
    titulo = input("  Ingresa el título del libro: ").strip()
    resp = stub.PrestamoPorTitulo(biblioteca_pb2.SolicitudTitulo(titulo=titulo))
    if resp.aprobado:
        print(f"  ✔ {resp.mensaje}")
        print(f"  ✔ Fecha de devolución: {resp.fecha_devolucion}")
    else:
        print(f"  ✘ {resp.mensaje}")


def consulta(stub):
    isbn = input("  Ingresa el ISBN a consultar: ").strip()
    resp = stub.Consulta(biblioteca_pb2.SolicitudISBN(isbn=isbn))
    if resp.encontrado:
        print(f"  ✔ Libro encontrado:")
        print(f"     Título  : {resp.titulo}")
        print(f"     Autor   : {resp.autor}")
        print(f"     Total   : {resp.ejemplares_total} ejemplar(es)")
        print(f"     Disponibles: {resp.ejemplares_disp}")
    else:
        print(f"  ✘ Libro no encontrado.")


def devolucion(stub):
    isbn = input("  Ingresa el ISBN del libro a devolver: ").strip()
    resp = stub.Devolucion(biblioteca_pb2.SolicitudISBN(isbn=isbn))
    if resp.exitoso:
        print(f"  ✔ {resp.mensaje}")
    else:
        print(f"  ✘ {resp.mensaje}")


# ─── Menú principal ───────────────────────────────────────────────────────────

MENU = """
╔══════════════════════════════════════╗
║      Cliente Biblioteca gRPC         ║
╠══════════════════════════════════════╣
║  1. Préstamo por ISBN                ║
║  2. Préstamo por título              ║
║  3. Consultar disponibilidad         ║
║  4. Registrar devolución             ║
║  0. Salir                            ║
╚══════════════════════════════════════╝
"""

OPCIONES = {
    "1": prestamo_isbn,
    "2": prestamo_titulo,
    "3": consulta,
    "4": devolucion,
}


def main():
    host   = sys.argv[1] if len(sys.argv) > 1 else "localhost"
    puerto = int(sys.argv[2]) if len(sys.argv) > 2 else 50051

    print(f"\nConectando a {host}:{puerto}...")
    try:
        stub = conectar(host, puerto)
        # Verificación rápida de conexión
        stub.Consulta(
            biblioteca_pb2.SolicitudISBN(isbn="test"),
            timeout=3
        )
    except grpc.RpcError as e:
        if e.code() == grpc.StatusCode.NOT_FOUND:
            pass  # Servidor responde, conexión OK aunque no exista ese ISBN
        else:
            print(f"  ✘ No se pudo conectar al servidor: {e.details()}")
            sys.exit(1)
    except Exception:
        pass  # Continuamos de todas formas

    print(f"  ✔ Conectado a {host}:{puerto}\n")

    while True:
        print(MENU)
        opcion = input("Selecciona una opción: ").strip()

        if opcion == "0":
            print("  Hasta luego.")
            break
        elif opcion in OPCIONES:
            print()
            try:
                OPCIONES[opcion](stub)
            except grpc.RpcError as e:
                print(f"  ✘ Error de comunicación: {e.details()}")
        else:
            print("  Opción inválida.")

        input("\n  Presiona Enter para continuar...")


if __name__ == "__main__":
    main()
