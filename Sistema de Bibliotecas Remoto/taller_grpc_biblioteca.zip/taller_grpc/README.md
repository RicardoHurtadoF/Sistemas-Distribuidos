# Taller RMI/gRPC — Sistema de Biblioteca
**Pontificia Universidad Javeriana · Introducción a Sistemas Distribuidos · Feb 2026**

Implementación de un servicio remoto de biblioteca utilizando **gRPC con Python**.

---

## Estructura del proyecto

```
taller_grpc/
├── biblioteca.proto         ← Contrato del servicio (mensajes + métodos)
├── biblioteca_pb2.py        ← [AUTOGENERADO] Clases de mensajes
├── biblioteca_pb2_grpc.py   ← [AUTOGENERADO] Servidor/cliente base
├── servidor.py              ← Implementación del servidor gRPC
├── cliente.py               ← Cliente interactivo con menú
├── libros.json              ← Base de datos (archivo JSON)
├── generar_codigo.sh        ← Script de generación (Linux/macOS)
├── generar_codigo.bat       ← Script de generación (Windows)
└── README.md
```

---

## Requisitos

- Python 3.8 o superior
- pip

---

## Pasos para ejecutar

### Paso 1 — Instalar dependencias y generar código

Ejecuta **una sola vez** en ambas computadoras:

**Linux / macOS:**
```bash
chmod +x generar_codigo.sh
./generar_codigo.sh
```

**Windows:**
```bat
generar_codigo.bat
```

Esto instala `grpcio` y `grpcio-tools`, y genera los archivos:
- `biblioteca_pb2.py`
- `biblioteca_pb2_grpc.py`

---

### Paso 2 — Ejecutar el servidor (Computadora A)

```bash
python servidor.py
```

O especificando un puerto distinto:
```bash
python servidor.py 50052
```

Verás:
```
╔══════════════════════════════════════╗
║  Servidor Biblioteca gRPC corriendo  ║
║  Puerto: 50051                       ║
╚══════════════════════════════════════╝
Esperando conexiones...
```

> **Importante:** Asegúrate de que el firewall del servidor permita el puerto 50051 (TCP).
>
> En Linux: `sudo ufw allow 50051`
>
> En Windows: Agregar regla de entrada en el Firewall de Windows para el puerto 50051.

---

### Paso 3 — Ejecutar el cliente (Computadora B)

Primero, encuentra la IP del servidor:
- Linux/macOS: `hostname -I`
- Windows: `ipconfig`

Luego conecta el cliente:
```bash
python cliente.py 192.168.1.XX 50051
```

Si estás en la misma máquina (pruebas locales):
```bash
python cliente.py localhost 50051
```

---

## Menú del cliente

```
╔══════════════════════════════════════╗
║      Cliente Biblioteca gRPC         ║
╠══════════════════════════════════════╣
║  1. Préstamo por ISBN                ║
║  2. Préstamo por título              ║
║  3. Consultar disponibilidad         ║
║  4. Registrar devolución             ║
║  0. Salir                            ║
╚══════════════════════════════════════╝
```

---

## Datos de prueba (libros.json)

| ISBN | Título | Autor | Total | Prestados |
|------|--------|-------|-------|-----------|
| 978-0-13-468599-1 | Clean Code | Robert C. Martin | 3 | 1 |
| 978-0-13-235088-4 | The Pragmatic Programmer | Andrew Hunt | 2 | 0 |
| 978-0-596-51774-8 | Python Cookbook | David Beazley | 4 | 4 |
| 978-0-13-110362-7 | The C Programming Language | Brian W. Kernighan | 2 | 0 |
| 978-0-201-63361-0 | Design Patterns | Gang of Four | 3 | 1 |

> **Python Cookbook** no tiene ejemplares disponibles → útil para probar respuesta negativa.

---

## Casos de prueba sugeridos (para el video)

### Con un solo cliente:

1. **Consulta** → ISBN `978-0-13-468599-1` → debe mostrar 2 disponibles
2. **Préstamo por ISBN** → mismo ISBN → debe aprobarse, mostrar fecha
3. **Consulta** nuevamente → ahora debe mostrar 1 disponible
4. **Préstamo por título** → `"Clean Code"` → debe aprobarse (aún hay 1)
5. **Consulta** → ahora debe mostrar 0 disponibles
6. **Préstamo por ISBN** → mismo → debe rechazarse (sin ejemplares)
7. **Devolución** → ISBN `978-0-13-468599-1` → debe registrarse
8. **Consulta** → debe volver a mostrar 1 disponible
9. **Préstamo** a libro inexistente → ISBN `000-0-00-000000-0` → error

### Con dos clientes:

Abre dos terminales en la computadora del cliente y corre `cliente.py` en ambas.
Desde el cliente 1 y el cliente 2 realiza préstamos simultáneos del mismo libro
para demostrar concurrencia y consistencia de la BD.

---

## Métodos remotos implementados

| Método | Descripción | Síncrono |
|--------|-------------|----------|
| `PrestamoPorISBN(isbn)` | Préstamo por ISBN. Retorna aprobado + fecha de devolución (hoy + 7 días) | ✔ |
| `PrestamoPorTitulo(titulo)` | Préstamo por título (búsqueda parcial). Retorna aprobado + fecha | ✔ |
| `Consulta(isbn)` | Retorna si el libro existe y cuántos ejemplares hay disponibles | ✔ |
| `Devolucion(isbn)` | Registra la devolución de un ejemplar en la BD | ✔ |

Todas las operaciones son **síncronas** (gRPC unario), tal como lo requiere el taller.

---

## Notas de implementación

- La "base de datos" es el archivo `libros.json`. Se actualiza en disco en cada préstamo/devolución.
- El servidor usa un `threading.Lock` para garantizar consistencia cuando múltiples clientes operan simultáneamente.
- La búsqueda por título es **case-insensitive** y acepta coincidencias parciales (ej: `"clean"` encuentra `"Clean Code"`).
- La fecha de devolución es siempre **7 días** a partir de la fecha del servidor.
